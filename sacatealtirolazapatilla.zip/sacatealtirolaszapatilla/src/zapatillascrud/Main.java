
package zapatillascrud;

import controlador.ControladorP;
import controlador.ControladorProducto;
import modelo.Conexion;
import modelo.ConsultasProducto;
import modelo.Producto;
import vista.vistaPrincipal;
import vista.vistaProducto;
public class Main {

    
    public static void main(String[] args) {
        Producto pro = new Producto();
        ConsultasProducto proC = new ConsultasProducto();
        vistaProducto frmPro = new vistaProducto();
        ControladorProducto ctrlPro = new ControladorProducto(pro,frmPro,proC);
        vistaPrincipal frmPri = new vistaPrincipal();
        ControladorP ctrlPri = new ControladorP(frmPri, frmPro);
        ctrlPri.iniciar();
        
        frmPri.setVisible(true);
        
    }
    
}
