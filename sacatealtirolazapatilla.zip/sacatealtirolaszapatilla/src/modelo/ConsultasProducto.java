
package modelo;
import java.sql.*;
public class ConsultasProducto extends Conexion{
    //Ingresar zapatillas a la DB
    public boolean registrar(Producto p) {
        PreparedStatement ps = null;
        Connection con  =  getConnection();
        String sql = "insert intro producto (codigo, nombre, precio) values(?,?,?)";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getCodigo());//AGREGAR EL PRIMER PARAMETRO
            ps.setString(2, p.getNombre());//AGREGAR EL PRIMER PARAMETRO
            ps.setInt(3, p.getPrecio());//AGREGAR EL PRIMER PARAMETRO
            ps.execute();
            return true;
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }
    }
    //modificar zapatilla
    public boolean modificar(Producto p) {
        PreparedStatement ps = null;
        Connection con  =  getConnection();
        String sql = "update producto set codigo=?, nombre=?, precio=? where id=?";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getCodigo());//AGREGAR EL PRIMER PARAMETRO
            ps.setString(2, p.getNombre());//AGREGAR EL PRIMER PARAMETRO
            ps.setInt(3, p.getPrecio());//AGREGAR EL PRIMER PARAMETRO
            ps.setInt(4, p.getId());//AGREGAR EL PRIMER PARAMETRO
            ps.execute();
            return true;
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }
    }
    //eliminar una zapatilla
    public boolean eliminar(Producto p) {
        PreparedStatement ps = null;
        Connection con  =  getConnection();
        String sql = "delete from producto where id= ?";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, p.getId());//AGREGAR EL PRIMER PARAMETRO
            ps.execute();
            return true;
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }
    }
    //buscar una zapatilla
    public boolean buscar(Producto p) {
        PreparedStatement ps = null;
        Connection con  =  getConnection();
        ResultSet rs = null;
        String sql = "select * from producto where id=?";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, p.getId());//AGREGAR EL PRIMER PARAMETRO
            rs = ps.executeQuery();
            if(rs.next()){
                p.setId(Integer.parseInt(rs.getString("id")));
                p.setCodigo(rs.getString("codigo"));
                p.setNombre(rs.getString("nombre"));
                p.setPrecio(Integer.parseInt(rs.getString("precio")));
                return true;
            }
            return false;
            
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }
    }
}
    
    