
package controlador;
import modelo.ConsultasProducto;
import modelo.Producto;
import vista.vistaProducto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
public class ControladorProducto implements ActionListener{
    private Producto pro;
    private vistaProducto frmPro;
    private ConsultasProducto proC;
    
    public ControladorProducto(Producto pro, vistaProducto frmPro, ConsultasProducto proC){
        this.pro = pro;
        this.frmPro = frmPro;
        this.proC = proC;
        //agregar funcionalidad a los botones
        
        this.frmPro.btn_agregar.addActionListener(this);
        this.frmPro.bt_buscar.addActionListener(this);
        this.frmPro.bt_eliminar.addActionListener(this);
        this.frmPro.bt_limpiar.addActionListener(this);
        this.frmPro.bt_modificar.addActionListener(this);
        
    }
    @Override
    public void actionPerformed(ActionEvent e){
        //metodo para manejar botones
        //agregar
        if(e.getSource()==frmPro.btn_agregar){
            pro.setCodigo(frmPro.txt_codigo.getText());
            pro.setNombre(frmPro.txt_nombre.getText());
            pro.setPrecio(Integer.parseInt(frmPro.txt_precio.getText()));
            if(proC.registrar(pro)){
                JOptionPane.showMessageDialog(null, "producto agregado con exito");
                limpiar();
            }else{
                JOptionPane.showMessageDialog(null, "El producto no ha podido ser agregado");
                limpiar();
            }
        }
        //modificar
        if(e.getSource()==frmPro.bt_modificar){
            pro.setId(Integer.parseInt(frmPro.txt_id.getText()));
            pro.setCodigo(frmPro.txt_codigo.getText());
            pro.setNombre(frmPro.txt_nombre.getText());
            pro.setPrecio(Integer.parseInt(frmPro.txt_precio.getText()));
            if(proC.modificar(pro)){
                JOptionPane.showMessageDialog(null, "producto modificado con exito");
                limpiar();
            }else{
                JOptionPane.showMessageDialog(null, "El producto no ha podido ser modificado");
                limpiar();
            }
        }
        //eliminar
        if(e.getSource()==frmPro.bt_eliminar){
            pro.setId(Integer.parseInt(frmPro.txt_id.getText()));;
            if(proC.eliminar(pro)){
                JOptionPane.showMessageDialog(null, "producto eliminado con exito");
                limpiar();
            }else{
                JOptionPane.showMessageDialog(null, "El producto no ha podido ser eliminado");
                limpiar();
            }
        }//buscar
        if(e.getSource()==frmPro.bt_buscar){
            pro.setId(Integer.parseInt(frmPro.txt_id.getText()));;
            if(proC.buscar(pro)){
                frmPro.txt_id.setText(String.valueOf(pro.getId()));
                frmPro.txt_codigo.setText(pro.getCodigo());
                frmPro.txt_nombre.setText(pro.getNombre());
                frmPro.txt_precio.setText(String.valueOf(pro.getPrecio()));
            }else{
                JOptionPane.showMessageDialog(null, "El producto no ha podido ser encontrado");
                limpiar();
            }
        }
        //limpiar
        if (e.getSource()==frmPro.bt_limpiar){
            limpiar();
        }
    }
    public void limpiar(){
            frmPro.txt_codigo.setText(null);
            frmPro.txt_id.setText(null);
            frmPro.txt_nombre.setText(null);
            frmPro.txt_precio.setText(null);
        }
}
