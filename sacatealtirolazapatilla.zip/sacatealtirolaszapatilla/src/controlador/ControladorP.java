
package controlador;
import vista.vistaPrincipal;
import vista.vistaProducto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorP implements ActionListener{
    private vistaPrincipal frmPri;
    private vistaProducto frmPro;
    
    public ControladorP(vistaPrincipal frmPri,vistaProducto frmPro){
        this.frmPri = frmPri;
        this.frmPro = frmPro;
        
        this.frmPri.menu_accion.addActionListener(this);
        this.frmPri.menu_archivo.addActionListener(this);
    }
    public void iniciar(){
        frmPri.setTitle("producto");
        frmPro.setTitle("principal");
        frmPri.setLocationRelativeTo(null);
        frmPro.setLocationRelativeTo(null);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==frmPri.menu_accion){
            frmPro.setVisible(true);
            frmPro.dispose();
        }
        if(e.getSource()==frmPri.menu_salir){
            System.exit(0);
        }
    }
    
}
